const Product = require('../models/Product');

// @desc    Fetch all products
// @route   GET /api/products
// @access  Public
exports.getProducts = async (req, res) => {
  try {
    const products = await Product.find();
    res.status(200).json(products);
  } catch (error) {
    console.error('Error fetching products:', error.message);
    res.status(500).json({ message: 'Failed to fetch products' });
  }
};

// @desc    Add a new product (for logged-in users)
// @route   POST /api/products/add
// @access  Private
exports.addProduct = async (req, res) => {
  try {
    const { name, price, image, category } = req.body;

    const newProduct = new Product({
      name,
      price,
      image,
      category,
    });

    await newProduct.save();
    res.status(201).json({ message: "Product added successfully" });
  } catch (err) {
    console.error("Add product error:", err.message);
    res.status(500).json({ message: "Failed to add product" });
  }
};
