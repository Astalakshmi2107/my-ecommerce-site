const Order = require('../models/Order');

exports.placeOrder = async (req, res) => {
  try {
    const userId = req.user._id;
    const items = req.body.items;

    // Format items to include productId, name, price, image, quantity
    const formattedItems = items.map(item => ({
      productId: item._id,
      name: item.name,
      price: item.price,
      image: item.image,
      quantity: item.quantity || 1
    }));

    // Calculate total
    const total = formattedItems.reduce(
      (sum, item) => sum + item.price * item.quantity,
      0
    );

    // Save order
    const order = await Order.create({
      userId,
      items: formattedItems,
      total
    });

    res.status(201).json({ message: '✅ Order placed successfully!', order });
  } catch (err) {
    console.error('Order placement failed:', err);
    res.status(500).json({ message: '❌ Failed to place order' });
  }
};

exports.getOrders = async (req, res) => {
  try {
    const orders = await Order.find({ userId: req.user._id }).sort({ createdAt: -1 });
    res.json(orders);
  } catch (err) {
    console.error('Error fetching orders:', err);
    res.status(500).json({ message: '❌ Failed to fetch orders' });
  }
};
