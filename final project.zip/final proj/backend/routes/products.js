const express = require('express');
const router = express.Router();
const { getProducts, addProduct } = require('../controllers/productController');
const protect = require('../middleware/authMiddleware');

// Public route: Get all products
router.get('/', getProducts);

// Protected route: Add new product
router.post('/add', protect, addProduct);

module.exports = router;

